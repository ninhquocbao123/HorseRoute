require('reflect-metadata');require('ts-node').register({project:require('path').resolve(__dirname,'../tsconfig.json'),transpileOnly:true});
const {test}=require('node:test');const assert=require('node:assert/strict');
const {openApiDocument:doc}=require('../src/shared/config/openapi');
test('Swagger preserves all routes, registration, nested horses and multipart security',()=>{
 const registration=doc.components.schemas.RegisterDto;
 for(const field of ['email','password','fullName','phone','address'])assert.ok(registration.required.includes(field),field);
 assert.equal(Object.values(doc.paths).reduce((n,p)=>n+Object.keys(p).length,0),84);
 assert.deepEqual(doc.paths['/api/v1/auth/register'].post.security,[]);
 assert.ok(doc.paths['/api/v1/orders/{id}/review'].post.security.length);
 assert.ok(doc.components.schemas.DraftOrderDto.properties.horses.items.$ref);
 assert.ok(doc.paths['/api/v1/documents/orders/{orderId}/items/{id}/upload'].post.requestBody.content['multipart/form-data']);
 assert.ok(doc.paths['/api/v1/documents/orders/{orderId}/files/{id}'].get.security.length);
});



test('Trip design contract exposes complete schemas, examples and explicit implementation status', () => {
 const operations = [
  ['/api/v1/trips', 'get', 'TripList'],
  ['/api/v1/trips/{id}', 'get', 'TripDetail'],
  ['/api/v1/trips/{id}/plan-options', 'get', 'TripPlanOptions'],
  ['/api/v1/trips/{id}/plan', 'put', 'TripDetail'],
 ];
 for (const [path, method, response] of operations) {
  const op = doc.paths[path][method];
  assert.equal(op['x-implementation-status'], 'implemented');
  assert.equal(op['x-contract-status'], 'proposed');
  assert.match(op.description, method === 'get' ? /ĐÃ TRIỂN KHAI API ĐỌC/ : /ĐÃ TRIỂN KHAI API LƯU KẾ HOẠCH/);
  assert.deepEqual(op.security, [{ bearer: [] }]);
  assert.equal(op.responses[200].content['application/json'].schema.$ref, '#/components/schemas/' + response);
  assert.ok(op.responses[200].headers['X-Request-ID']);
  assert.ok(op.responses[500]);
 }
 const input = doc.components.schemas.TripPlanInput;
 assert.equal(input.additionalProperties, false);
 assert.deepEqual(input.required, ['legs']);
 assert.equal(input.properties.legs.minItems, 1);
 assert.equal(input.properties.legs.maxItems, 50);
 const leg = doc.components.schemas.TripPlanLegInput;
 assert.equal(leg.additionalProperties, false);
 assert.ok(!leg.required.includes('id'));
 assert.ok(!leg.properties.planStatus);
 assert.equal(doc.components.schemas.TripLeg.properties.vehicleStatus.nullable, true);
 const save = doc.paths['/api/v1/trips/{id}/plan'].put;
 const examples = save.requestBody.content['application/json'].examples;
 assert.ok(examples.firstSave.value.legs.every(x => x.id === undefined));
 assert.deepEqual(examples.editExisting.value.legs.map(x => x.id), ['301', '302']);
 assert.ok(save.responses[409]);
 assert.ok(!doc.paths['/api/v1/trips'].get.responses[409]);
 assert.equal(doc.paths['/api/v1/trips/{id}'].get.responses[200].content['application/json'].examples.noLegs.value.legs.length, 0);
 assert.ok(!doc.paths['/api/v1/trips'].post, 'No second Trip creation endpoint');
 assert.equal(doc.components.schemas.Error.properties.requestId.format, 'uuid');
});

test('All OpenAPI references resolve and Trip response examples match declared required fields', () => {
 function visit(value) {
  if (!value || typeof value !== 'object') return;
  if (value.$ref) {
   assert.ok(value.$ref.startsWith('#/'));
   const target = value.$ref.slice(2).split('/').reduce((o, key) => o?.[key], doc);
   assert.ok(target, value.$ref);
  }
  Object.values(value).forEach(visit);
 }
 visit(doc);
 function validate(value, schema) {
  if (schema.$ref) schema = { ...doc.components.schemas[schema.$ref.split('/').at(-1)], ...schema };
  if (value === null) { assert.ok(schema.nullable); return; }
  if (schema.type === 'object') {
   for (const key of schema.required || []) assert.ok(key in value, key);
   for (const [key, child] of Object.entries(value)) {
    assert.ok(schema.properties[key], key);
    validate(child, schema.properties[key]);
   }
  } else if (schema.type === 'array') {
   assert.ok(Array.isArray(value));
   if (schema.minItems) assert.ok(value.length >= schema.minItems);
   if (schema.maxItems) assert.ok(value.length <= schema.maxItems);
   value.forEach(item => validate(item, schema.items));
  } else if (schema.type === 'integer') {
   assert.ok(Number.isInteger(value));
   if (schema.minimum !== undefined) assert.ok(value >= schema.minimum);
  } else {
   assert.equal(typeof value, schema.type);
  }
  if (schema.enum) assert.ok(schema.enum.includes(value));
  if (schema.pattern) assert.match(value, new RegExp(schema.pattern));
  if (schema.format === 'date-time') assert.ok(!Number.isNaN(Date.parse(value)));
 }
 for (const [path, item] of Object.entries(doc.paths)) {
  if (!path.startsWith('/api/v1/trips')) continue;
  for (const op of Object.values(item)) {
   const media = op.responses[200].content['application/json'];
   for (const example of Object.values(media.examples)) validate(example.value, media.schema);
   const body = op.requestBody?.content['application/json'];
   if (body) for (const example of Object.values(body.examples)) validate(example.value, body.schema);
  }
 }
});

test('Submit plan is documented as implemented, accepted, authenticated with strict empty body',()=>{
 const op=doc.paths['/api/v1/trips/{id}/submit-plan'].post;
 assert.equal(op['x-implementation-status'],'implemented');assert.equal(op['x-contract-status'],'accepted');
 assert.deepEqual(op.security,[{bearer:[]}]);assert.equal(doc.components.schemas.SubmitTripPlanInput.additionalProperties,false);
 assert.deepEqual(doc.components.schemas.SubmitTripPlanInput.properties,{});assert.ok(op.responses[409]);
});

test('Review plan documents decisions and review metadata in TripDetail',()=>{
 const op=doc.paths['/api/v1/trips/{id}/review-plan'].post;
 assert.equal(op['x-implementation-status'],'implemented');assert.deepEqual(op.security,[{bearer:[]}]);
 assert.equal(op.requestBody.content['application/json'].schema.$ref,'#/components/schemas/ReviewTripPlanInput');
 for(const key of ['orderStatus','approvedBy','approvedAt','returnReason']) assert.ok(doc.components.schemas.TripDetail.required.includes(key));
 assert.equal(doc.components.schemas.ReviewTripPlanInput.oneOf.length,2);
});

test('Crew API documents strict input, both roles and crew-only readiness',()=>{
 for(const [path,method] of [['/api/v1/trips/{id}/assignment-options','get'],['/api/v1/trips/{id}/assignments','get'],['/api/v1/trips/{id}/assignments','put']]) {
  const op=doc.paths[path][method];assert.equal(op['x-implementation-status'],'implemented');assert.deepEqual(op.security,[{bearer:[]}]);
 }
 const input=doc.components.schemas.TripAssignmentsInput;
 assert.equal(input.additionalProperties,false);assert.equal(input.properties.assignments.items.additionalProperties,false);
 assert.equal(input.properties.assignments.minItems,2);assert.equal(input.properties.assignments.maxItems,100);
 assert.ok(doc.components.schemas.TripAssignments.properties.crewReadiness);
});

test('Manual readiness endpoints are removed and assignment documents automatic READY', () => {
 assert.ok(!doc.paths['/api/v1/trips/{id}/readiness']);
 assert.ok(!doc.paths['/api/v1/orders/{id}/mark-ready']);
 assert.ok(!doc.components.schemas.TripReadiness);
 assert.ok(!doc.components.schemas.MarkReadyResult);
 assert.ok(!doc.components.schemas.Error.properties.blockers);
 assert.match(doc.paths['/api/v1/trips/{id}/assignments'].put.description, /tự động chuyển READY/);
});

test('Flow 4 tracking contract documents every implemented endpoint with security, uploads and errors', () => {
 const expected = [
  ['/api/v1/tracking/driver/trips', 'get'], ['/api/v1/tracking/trips/{id}', 'get'],
  ['/api/v1/tracking/legs/{legId}/milestones', 'post'], ['/api/v1/tracking/legs/{legId}/complete', 'post'], ['/api/v1/tracking/legs/{legId}/correct', 'patch'],
  ['/api/v1/tracking/legs/{legId}/horse-logs', 'post'], ['/api/v1/tracking/trips/{tripId}/horse-logs', 'get'],
  ['/api/v1/tracking/trips/{tripId}/incidents', 'post'], ['/api/v1/tracking/trips/{tripId}/incidents', 'get'],
  ['/api/v1/tracking/incidents/{id}', 'patch'],
  ['/api/v1/tracking/trips/{tripId}/alerts', 'post'], ['/api/v1/tracking/trips/{tripId}/alerts', 'get'],
  ['/api/v1/tracking/attachments/{id}', 'get'],
  ['/api/v1/tracking/orders/{orderId}/timeline', 'get'], ['/api/v1/tracking/trips/{tripId}/timeline', 'get'], ['/api/v1/tracking/operations/active-trips', 'get'],
  ['/api/v1/tracking/trips/{tripId}/map', 'get'], ['/api/v1/tracking/trips/{tripId}/positions', 'post'], ['/api/v1/tracking/trips/{tripId}/positions', 'get'],
 ];
 for (const [path, method] of expected) {
  const op = doc.paths[path][method];
  assert.ok(op, path + ' ' + method);
  assert.deepEqual(op.security, [{ bearer: [] }]);
  assert.deepEqual(op.tags, ['Flow 4 - Tracking']);
  assert.equal(op['x-implementation-status'], 'implemented');
  assert.ok(op.responses[401] && op.responses[403]);
 }
 assert.ok(doc.tags.some(tag => tag.name === 'Flow 4 - Tracking'));
 for (const path of ['/api/v1/tracking/legs/{legId}/horse-logs', '/api/v1/tracking/trips/{tripId}/incidents']) {
  const body = doc.paths[path].post.requestBody.content;
  assert.ok(body['multipart/form-data'].schema.allOf[1].properties.photos.maxItems === 3);
  assert.ok(body['application/json']);
 }
 assert.ok(doc.paths['/api/v1/tracking/legs/{legId}/milestones'].post.responses[409]);
 assert.equal(doc.components.schemas.CorrectLegInput.properties.reason.maxLength, 255);
 assert.ok(doc.components.schemas.CorrectLegInput.required.includes('reason'));
 assert.ok(!doc.paths['/api/v1/tracking/trips/{id}'].get.description.includes('Customer xem'));
 assert.ok(doc.paths['/api/v1/tracking/attachments/{id}'].get.responses[200].content['image/jpeg']);
});

test('Locations catalog documents Specialist CRUD with required coordinates and plan-options coordinates', () => {
 const expected = [['/api/v1/locations', 'get'], ['/api/v1/locations', 'post'], ['/api/v1/locations/{id}', 'get'], ['/api/v1/locations/{id}', 'put'], ['/api/v1/locations/{id}', 'delete']];
 for (const [path, method] of expected) {
  const op = doc.paths[path][method];
  assert.ok(op, path + ' ' + method);
  assert.deepEqual(op.security, [{ bearer: [] }]);
  assert.deepEqual(op.tags, ['Flow 3 - Locations']);
  assert.equal(op['x-implementation-status'], 'implemented');
  assert.ok(op.responses[401] && op.responses[403] && op.responses[500]);
 }
 for (const [path, method] of expected.slice(1).filter(([, m]) => m !== 'get')) assert.ok(doc.paths[path][method].responses[409], path + ' ' + method);
 const input = doc.components.schemas.LocationInput;
 assert.equal(input.additionalProperties, false);
 for (const key of ['latitude', 'longitude', 'timezone', 'country']) assert.ok(input.required.includes(key), key);
 assert.ok(!input.required.includes('address'));
 const item = doc.components.schemas.Location;
 for (const key of ['legCount', 'ruleCount', 'inActiveUse']) assert.ok(item.required.includes(key), key);
 assert.equal(item.properties.latitude.nullable, true);
 const option = doc.components.schemas.TripLocationOption;
 assert.equal(option.properties.latitude.nullable, true);
 assert.ok(option.required.includes('longitude'));
 assert.ok(doc.tags.some(tag => tag.name === 'Flow 3 - Locations'));
});
