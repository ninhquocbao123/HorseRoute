const {test}=require('node:test');const assert=require('node:assert/strict');
require('reflect-metadata');require('ts-node').register({project:require('path').resolve(__dirname,'../tsconfig.json'),transpileOnly:true});
const {registerSchema}=require('../src/features/auth/auth.validation');const {AuthService}=require('../src/features/auth/auth.service');const bcrypt=require('bcrypt');
const input={fullName:'  Nguyễn Văn An  ',email:'AN@example.com',phone:'0901234567',address:'123 Nguyễn Huệ, TP.HCM',password:'Examplepass123'};
test('registration requires all five fields and rejects role injection',async()=>{for(const field of Object.keys(input)){const value={...input};delete value[field];assert.ok(!registerSchema.safeParse(value).success,field);}assert.ok(!registerSchema.safeParse({...input,role:'ADMIN'}).success);});
test('registration rejects blank profile, invalid phone and short password',async()=>{for(const change of [{fullName:'   '},{address:'   '},{phone:'abc'},{password:'short'},{password:'        '}])assert.ok(!registerSchema.safeParse({...input,...change}).success);});
test('registration persists profile, hashes password and forces Customer',async()=>{let saved;const service=new AuthService({findByEmailWithPassword:async()=>null,create:async data=>(saved={id:'1',...data})},{sign:()=> 'test-token'});const result=await service.register(registerSchema.parse(input));assert.equal(saved.role,'CUSTOMER');assert.equal(saved.fullName,'Nguyễn Văn An');assert.equal(saved.email,'an@example.com');assert.equal(saved.phone,input.phone);assert.equal(saved.address,input.address);assert.ok(await bcrypt.compare(input.password,saved.passwordHash));assert.ok(!('passwordHash' in result.user));});
test('duplicate email race returns Conflict',async()=>{const service=new AuthService({findByEmailWithPassword:async()=>null,create:async()=>{throw {code:'ER_DUP_ENTRY'}}},{sign:()=>''});await assert.rejects(()=>service.register(input),e=>e.getStatus()===409);});
test('UTF8 passwords cannot exceed bcrypt 72-byte boundary',async()=>{const service=new AuthService({},{});await assert.rejects(()=>service.register({...input,password:'ế'.repeat(30)}),e=>e.getStatus()===400);});
test('login rejects incorrect password and locked accounts',async()=>{const hash=await bcrypt.hash('correct-password',4);for(const accountStatus of ['ACTIVE','LOCKED']){const service=new AuthService({findByEmailWithPassword:async()=>({accountStatus,passwordHash:hash})},{});await assert.rejects(()=>service.login('a@b.com','wrong'),e=>e.getStatus()===401);}});

test('club registration requires and persists organization without changing role',async()=>{
 assert.equal(registerSchema.safeParse({...input,customerType:'CLUB'}).success,false);
 assert.equal(registerSchema.safeParse({...input,customerType:'ADMIN'}).success,false);
 let saved;
 const service=new AuthService({findByEmailWithPassword:async()=>null,create:async data=>(saved={id:'2',...data})},{sign:()=> 'test-token'});
 await service.register(registerSchema.parse({...input,customerType:'CLUB',organizationName:'  CLB Ngựa  '}));
 assert.equal(saved.customerType,'CLUB');assert.equal(saved.organizationName,'CLB Ngựa');assert.equal(saved.role,'CUSTOMER');
});
